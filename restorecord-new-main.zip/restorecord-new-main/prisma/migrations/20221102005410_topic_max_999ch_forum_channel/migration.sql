-- AlterTable
ALTER TABLE `channels` MODIFY `topic` VARCHAR(999) NULL;
