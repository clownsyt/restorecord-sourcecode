-- AlterTable
ALTER TABLE `servers` ADD COLUMN `discoverable` INTEGER NOT NULL DEFAULT 0;
