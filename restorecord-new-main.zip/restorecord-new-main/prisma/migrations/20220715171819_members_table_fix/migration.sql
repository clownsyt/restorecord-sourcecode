-- DropIndex
DROP INDEX `members_userId_key` ON `members`;
