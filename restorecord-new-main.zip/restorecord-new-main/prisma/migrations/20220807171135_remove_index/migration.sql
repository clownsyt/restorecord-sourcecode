-- DropIndex
DROP INDEX `members_userId_guildId_idx` ON `members`;
