-- AlterTable
ALTER TABLE `servers` MODIFY `picture` VARCHAR(191) NULL DEFAULT 'https://cdn.restorecord.com/logo512.png';
