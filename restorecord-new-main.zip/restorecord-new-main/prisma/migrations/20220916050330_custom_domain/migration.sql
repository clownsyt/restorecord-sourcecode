-- AlterTable
ALTER TABLE `servers` ADD COLUMN `customDomain` VARCHAR(191) NULL;
