-- AlterTable
ALTER TABLE `guildMembers` MODIFY `roles` LONGTEXT NOT NULL;
