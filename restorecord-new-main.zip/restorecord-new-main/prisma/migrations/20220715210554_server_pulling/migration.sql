-- AlterTable
ALTER TABLE `servers` ADD COLUMN `pulling` BOOLEAN NOT NULL DEFAULT false;
