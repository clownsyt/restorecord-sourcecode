-- AlterTable
ALTER TABLE `servers` MODIFY `description` VARCHAR(191) NOT NULL DEFAULT 'Verify to view the rest of the server.';
