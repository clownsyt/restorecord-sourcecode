-- AlterTable
ALTER TABLE `customBots` ADD COLUMN `publicKey` VARCHAR(191) NULL;
