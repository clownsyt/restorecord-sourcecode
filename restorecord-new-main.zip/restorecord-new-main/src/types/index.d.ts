/* eslint-disable no-var */

declare global {
	var db: any;
}

export {};