export interface WidgetData {
    enabled: boolean | null;
    channel?: string | null;
}
