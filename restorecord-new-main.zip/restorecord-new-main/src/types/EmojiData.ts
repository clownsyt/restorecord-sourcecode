export interface EmojiData {
    name: string | null;
    url?: string;
    base64?: string;
}
