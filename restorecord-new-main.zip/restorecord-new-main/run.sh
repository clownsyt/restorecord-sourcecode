git pull

npm i

npm run build

pm2 restart all

echo "Deployed Successfully!"